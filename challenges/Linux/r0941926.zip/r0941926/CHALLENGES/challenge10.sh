for f in $(find -name "file[0-9][0-9][0-9]"); do mv "$f" "${f}b"; done
