find data -type f -size +511c > bigfiles.txt
