cat data.dat | awk '{print $2,$5}' > summary.dat
