cat a.bf b.bf c.bf > abc.bf
