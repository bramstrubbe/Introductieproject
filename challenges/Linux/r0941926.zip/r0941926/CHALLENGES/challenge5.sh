cp -r source target
