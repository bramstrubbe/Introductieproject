sha1sum original.txt | awk '{print $1}' > hash.txt
