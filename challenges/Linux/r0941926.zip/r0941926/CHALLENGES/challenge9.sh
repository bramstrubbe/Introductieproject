grep -E "^[^#]" input.txt > output.txt
